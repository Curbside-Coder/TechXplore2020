import React from 'react';
import {
  MDBEdgeHeader,
  MDBFreeBird,
  MDBContainer,
  MDBCol,
  MDBRow,
  MDBCardBody,
  MDBIcon,
  MDBCard,
  MDBCardTitle,
  MDBCardImage,
  MDBCardText,
  MDBAnimation,
  MDBNavLink,


  MDBInput,
  MDBBtn,


  MDBModalFooter
} from 'mdbreact';
import './HomePage.css';

import SectionContainer from '../components/sectionContainer';

class HomePage extends React.Component {
  scrollToTop = () => window.scrollTo(0, 0);

  render() {
    return (
      <>
        <MDBEdgeHeader color='indigo darken-3' className='sectionPage' />
        <div className='mt-3 mb-5'>
          <MDBFreeBird>
            <MDBRow>
              <MDBCol
                md='4'
                className='mx-auto float-none white z-depth-1 py-2 px-2'
              >
                <MDBCardBody className='text-center'>


                  <MDBRow>
                    <MDBCol md='12'>

                      <form>
                        <p className='h5 text-center mb-4'>Register for Medical Consultation</p>
                     
                        <br/>
                        Are you a...?
                        <br/>
                        <br/>
                        


                          <div className='custom-control custom-radio'>
                            <input
                              type='radio'
                              className='custom-control-input'
                              id='radioDoctor'
                              name='radio-stacked'
                              required
                            />
                            <label
                              className='custom-control-label'
                              htmlFor='radioDoctor'
                            >
                              Doctor
                              
                              </label>
                          </div>

                          <div className='grey-text'>
                         or
                         </div>
                         
                          <div className='custom-control custom-radio mb-3'>
                            <input
                              type='radio'
                              className='custom-control-input'
                              id='radioPatient'
                              name='radio-stacked'
                              required
                            />
                            <label
                              className='custom-control-label'
                              htmlFor='radioPatient'
                            >
                              Patient
                </label>
                            <div className='invalid-feedback'>
                              More example invalid feedback text
                </div>
                          </div>


                          <div className='grey-text'>
                          <MDBInput
                            name='fname'
                            onChange={this.changeHandler}
                            type='text'
                            id='fname'
                            label='First name'
                            required
                          />

                          <MDBInput
                            name='mname'
                            onChange={this.changeHandler}
                            type='text'
                            id='mname'
                            label='Middle name'
                            required
                          />

                          <MDBInput
                            name='lname'
                            onChange={this.changeHandler}
                            type='text'
                            id='lname'
                            label='Last name'
                            required
                          />

                        <MDBInput
                            onChange={this.changeHandler}
                            type='text'
                            id='contact'
                            name='contact'
                            label='Contact #'
                            required
                          />

                          <MDBInput
                            onChange={this.changeHandler}
                            type='email'
                            id='email'
                            name='email'
                            label='Your Email address'
                            required
                          />

                          <MDBInput
                            type='textarea'
                            id='address'
                            name='address'
                            label='Home Address'
                            required
                          />

                          





                          <MDBBtn color='primary' type='submit'>
                            Register
                          </MDBBtn>

                        </div>

                      </form>

                    </MDBCol>
                  </MDBRow>

                </MDBCardBody>
              </MDBCol>
            </MDBRow>
          </MDBFreeBird>
          <MDBContainer>

          </MDBContainer>
        </div>
      </>
    );
  }
}

export default HomePage;
