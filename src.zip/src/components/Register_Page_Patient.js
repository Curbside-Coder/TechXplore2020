import React, { Component } from 'react';
import {
   MDBContainer, MDBFreeBird, MDBCardTitle, MDBRow, MDBCol, MDBBtn, MDBCard, MDBCardBody, MDBInput, MDBEdgeHeader, MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBFormInline,
   MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem
} from 'mdbreact';
import { BrowserRouter as Router } from 'react-router-dom';
import logo from "../logo.png";

const Register_Page_Patient = () => {
   return (
      <div>
        

         <MDBEdgeHeader color="mdb-color sunny-morning-gradient"></MDBEdgeHeader>
         <MDBContainer>
            <MDBFreeBird>
               <MDBRow>
                  <MDBCol md="8" lg="7" className="mx-auto float-none white z-depth-1 py-2 px-2">
                     <MDBCardBody>


                        <form>
                           <p className="h1 text-center mb-4">Hi there!</p>
                           <p className="h6 text-center mb-4">Please complete this form.</p>
                           <div className="grey-text">
                              <MDBInput label="First Name" group type="text" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Middle Name" group type="text" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Last Name" group type="text" validate error="wrong"
                                 success="right" />

                              <label style={{ float: "left" }}>Gender</label>
                              <select className="browser-default custom-select">
                                 <option></option>
                                 <option value="Male">Male</option>
                                 <option value="Female">Female</option>
                              </select>

                              <br />
                              <br />
                              <br />

                              <MDBInput label="Date of Birth" group type="date" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Address" group type="textarea" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Contact Number" group type="text" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Illness / Health Issues / Notes" group type="textarea" validate error="wrong"
                                 success="right" />

                              <br />


                              <MDBInput label="Your email" group type="email" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Desired password" group type="password" validate />

                              <MDBInput label="Confirm password" group type="password" validate />

                           </div>
                           <div className="text-center">
                              <MDBBtn className="sunny-morning-gradient">Register</MDBBtn>
                           </div>
                        </form>
                     </MDBCardBody>

                  </MDBCol>
               </MDBRow>
            </MDBFreeBird>






            <MDBRow center style={{ margin: "10vh 0px " }}>
               <MDBCol middle="true" sm="8" className="text-center">
                  <MDBCard  >

                  </MDBCard>
               </MDBCol>
            </MDBRow>




            <MDBRow>
               <MDBCol md="6">

               </MDBCol>
            </MDBRow>
         </MDBContainer>
      </div >
   );
}

export default Register_Page_Patient;