import React, { Component } from 'react';
import {
   MDBContainer, MDBFreeBird, MDBCardTitle, MDBRow, MDBCol, MDBBtn, MDBCard, MDBCardBody, MDBInput, MDBEdgeHeader, MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBFormInline,
   MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem
} from 'mdbreact';
import { BrowserRouter as Router } from 'react-router-dom';
import logo from "../logo.png";

const Navigation = () => {
    return (

        <MDBNavbar color="blue-gradient" dark expand="md">
            <MDBNavLink to="/">
                <MDBNavbarBrand>
                    <img src={logo} alt="logo" style={{ height: "3rem" }} />
                    <strong className="white-text">&nbsp;teleOPD </strong>
                </MDBNavbarBrand>
            </MDBNavLink>
        </MDBNavbar>
    );
}

export default Navigation;