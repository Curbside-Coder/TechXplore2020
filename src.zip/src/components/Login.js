import React, { Component } from 'react';
import {
   MDBContainer, MDBFreeBird, MDBCardTitle, MDBRow, MDBCol, MDBBtn, MDBCard, MDBCardBody, MDBInput, MDBEdgeHeader, MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBFormInline,
   MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem
} from 'mdbreact';
import { BrowserRouter as Router } from 'react-router-dom';
import logo from "../logo.png";

const Login = () => {
   return (
      <div>


         <MDBEdgeHeader color="mdb-color blue-gradient"></MDBEdgeHeader>

         <MDBContainer>
            <MDBFreeBird>
               <MDBRow>
                  <MDBCol md="8" lg="5" className="mx-auto float-none white z-depth-1 py-2 px-2">
                     <MDBCardBody>
                        <form>
                           <p className="h1 text-center mb-4">Log in</p>
                           <div className="grey-text">
                              <MDBInput label="Email" group type="email" validate error="wrong"
                                 success="right" />
                              <MDBInput label="Password" group type="password" validate />
                           </div>
                           <div className="text-center">
                              <MDBBtn className="blue-gradient">Login</MDBBtn>
                           </div>
                        </form>
                     </MDBCardBody>
                  </MDBCol>
               </MDBRow>
            </MDBFreeBird>


         </MDBContainer>
         <div style={{height: "30vh"}}>

         </div>

      </div >
   );
}

export default Login;