import React, { Component } from "react";
import { MDBBtn, MDBCol, MDBContainer, MDBRow } from "mdbreact";
import "../index.css";
import logo from "../logo.png";

import { NavLink } from 'react-router-dom';
// class App extends Component {
//   render() {
//     return (



//       <MDBContainer>
//         <MDBRow center style={{ height: "100vh" }}>
//           <MDBCol middle="true" sm="8" className="text-center">
//             <img src={logo} alt="logo" style={{ width: "10rem" }} />
//             <h1>Welcome to teleOPD!</h1>
//             <p className="mb-2">Book an online consultation, or serve your fellow Filipinos despite this Pandemic.</p>
//             <br/><br/>
//             <h4>Are you a Doctor or a Patient?</h4>
//             <br/>
//             <MDBBtn href="https://mdbootstrap.com/docs/react/" target="blank" size="lg" className="blue-gradient"><strong>I'm a Doctor</strong></MDBBtn>
//             <MDBBtn href="https://mdbootstrap.com/docs/react/" target="blank" size="lg" className="sunny-morning-gradient"><strong>I'm a Patient</strong></MDBBtn>
//             <br/><br/><br/><br/>
//             <h5>Already registered? <a href="">Login</a> instead.</h5>

//           </MDBCol>
//         </MDBRow>



//       </MDBContainer>
//     );
//   }
// }

// export default App;

// import React from 'react';

const home = () => {



    return (

        <MDBContainer>


            <MDBRow center style={{ height: "100vh" }}>
                <MDBCol middle="true" sm="8" className="text-center">
                    <img src={logo} alt="logo" style={{ width: "10rem" }} />
                    <h1>Welcome to teleOPD!</h1>
                    <p className="mb-2">Book an online consultation, or serve your fellow Filipinos despite this Pandemic.</p>
                    <br /><br />
                    <h4>Are you a Doctor or a Patient?</h4>
                    <br />

                    <NavLink to="/register_page_doctor">
                        <MDBBtn size="lg" className="aqua-gradient"><strong>I'm a Doctor</strong></MDBBtn>
                    </NavLink>

                    <NavLink to="/register_page_patient">
                        <MDBBtn size="lg" className="sunny-morning-gradient"><strong>I'm a Patient</strong></MDBBtn>
                    </NavLink>

                    <br /><br /><br /><br />
                    <h5>Already registered? <NavLink to="/login">Login</NavLink> instead.</h5>

                    {/* <NavLink to="/login"> <h5>Backdoor</h5></NavLink> */}


                </MDBCol>
            </MDBRow>

        </MDBContainer>


    );
}

export default home;