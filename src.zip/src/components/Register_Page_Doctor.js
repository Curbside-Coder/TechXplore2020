import React, { Component } from 'react';
import {
   MDBContainer, MDBFreeBird, MDBCardTitle, MDBRow, MDBCol, MDBBtn, MDBCard, MDBCardBody, MDBInput, MDBEdgeHeader, MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBFormInline,
   MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem
} from 'mdbreact';
import { BrowserRouter as Router } from 'react-router-dom';
import logo from "../logo.png";

const Register_Page_Doctor = () => {
   return (
      <div>
         
         <MDBEdgeHeader color="mdb-color aqua-gradient"></MDBEdgeHeader>
         <MDBContainer>




            <MDBFreeBird>
               <MDBRow>
                  <MDBCol md="8" lg="7" className="mx-auto float-none white z-depth-1 py-2 px-2">
                     <MDBCardBody>


                        <form>
                           <p className="h1 text-center mb-4">Hi Doc!</p>
                           <p className="h6 text-center mb-4">Please complete this form.</p>
                           <div className="grey-text">
                              <MDBInput label="First Name" group type="text" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Middle Name" group type="text" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Last Name" group type="text" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Specialization. Use comma ( , ) if more than one." group type="textarea" validate error="wrong"
                                 success="right" />

                              <label style={{ float: "left" }}>Gender</label>
                              <select className="browser-default custom-select">
                                 <option></option>
                                 <option value="Male">Male</option>
                                 <option value="Female">Female</option>
                              </select>

                              <MDBInput label="Address" group type="textarea" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Hospital(s) affiliated. Use comma ( , ) if more than one." group type="textarea" validate error="wrong"
                                 success="right" />

                              <label style={{ float: "left" }}>Availability</label>
                              <br />
                              {/* Sun */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkSun" />
                                 <label class="custom-control-label" for="chkSun">Sun</label>
                              </div>

                              {/* Mon */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkMon" />
                                 <label class="custom-control-label" for="chkMon">Mon</label>
                              </div>

                              {/* Tue */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkTue" />
                                 <label class="custom-control-label" for="chkTue">Tue</label>
                              </div>

                              {/* Wed */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkWed" />
                                 <label class="custom-control-label" for="chkWed">Wed</label>
                              </div>

                              {/* Thu */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkThu" />
                                 <label class="custom-control-label" for="chkThu">Thu</label>
                              </div>

                              {/* Fri */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkFri" />
                                 <label class="custom-control-label" for="chkFri">Fri</label>
                              </div>

                              {/* Sat */}
                              <div class="custom-control custom-checkbox custom-control-inline">
                                 <input type="checkbox" class="custom-control-input" id="chkSat" />
                                 <label class="custom-control-label" for="chkSat">Sat</label>
                              </div>

                              <br />
                              <br />
                              <br />

                              <MDBInput label="Your email" group type="email" validate error="wrong"
                                 success="right" />

                              <MDBInput label="Desired password" group type="password" validate />

                              <MDBInput label="Confirm password" group type="password" validate />

                           </div>
                           <div className="text-center">
                              <MDBBtn className="aqua-gradient">Register</MDBBtn>
                           </div>
                        </form>
                     </MDBCardBody>

                  </MDBCol>
               </MDBRow>
            </MDBFreeBird>






            <MDBRow center style={{ margin: "10vh 0px " }}>
               <MDBCol middle="true" sm="8" className="text-center">
                  <MDBCard  >

                  </MDBCard>
               </MDBCol>
            </MDBRow>




            <MDBRow>
               <MDBCol md="6">

               </MDBCol>
            </MDBRow>
         </MDBContainer>
      </div >
   );
}

export default Register_Page_Doctor;