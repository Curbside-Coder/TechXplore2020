import React from "react";
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

const FooterPage = () => {
  return (
        
      <div className="blue-gradient footer-copyright text-center py-3">
        <MDBContainer fluid>
          &copy; {new Date().getFullYear()} Copyright: <a href="https://curbsidecoder.tech.blog" target="_blank" style={{ color: "white" }}>  Curbside Coder </a>
        </MDBContainer>
      </div> 
  );
}

export default FooterPage;