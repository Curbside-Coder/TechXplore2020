// import React, { Component } from "react";
// import { MDBBtn, MDBCol, MDBContainer, MDBRow } from "mdbreact";
// import "./index.css";
// import logo from "./logo.png";


// import { BrowserRouter, Route, Switch } from 'react-router-dom';
// import Home from './components/Home';
// import About from './components/About';
// import Contact from './components/Contact';
// import Error from './components/Error';
// import Navigation from './components/Navigation';

// class App extends Component {
//   render() {
//     return (

      

//       <MDBContainer>
//         <MDBRow center style={{ height: "100vh" }}>
//           <MDBCol middle="true" sm="8" className="text-center">
//             <img src={logo} alt="logo" style={{ width: "10rem" }} />
//             <h1>Welcome to teleOPD!</h1>
//             <p className="mb-2">Book an online consultation, or serve your fellow Filipinos despite this Pandemic.</p>
//             <br/><br/>
//             <h4>Are you a Doctor or a Patient?</h4>
//             <br/>
//             <MDBBtn href="https://mdbootstrap.com/docs/react/" target="blank" size="lg" className="blue-gradient"><strong>I'm a Doctor</strong></MDBBtn>
//             <MDBBtn href="https://mdbootstrap.com/docs/react/" target="blank" size="lg" className="sunny-morning-gradient"><strong>I'm a Patient</strong></MDBBtn>
//             <br/><br/><br/><br/>
//             <h5>Already registered? <a href="">Login</a> instead.</h5>
             
//           </MDBCol>
//         </MDBRow>


        
//       </MDBContainer>
//     );
//   }
// }

// export default App;
import React, { Component } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
 
import Home from './components/Home';
import About from './components/Login';
import Register_Page_Doctor from './components/Register_Page_Doctor';
import Register_Page_Patient from './components/Register_Page_Patient';
import Error from './components/Error';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
 
class App extends Component {
  render() {
    return (      
       <BrowserRouter>
        <div>
          <Navigation />
            <Switch>
             <Route path="/" component={Home} exact/>
             <Route path="/login" component={About}/>
             <Route path="/register_page_doctor" component={Register_Page_Doctor}/>
             <Route path="/register_page_patient" component={Register_Page_Patient}/>
            <Route component={Error}/>
           </Switch>
          <Footer />
        </div> 
      </BrowserRouter>
    );
  }
}
 
export default App;